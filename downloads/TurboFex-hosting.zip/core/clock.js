// Time helpers. The time zone comes from (in order): TIMEZONE variable, config.js "timezone", or Johannesburg.
const config = require('../config');

function saved() {
  try {
    return require('../whatsapp/store').getRegion(); // chosen with the "region" command (loaded late: no circular import)
  } catch (err) {
    return null;
  }
}

// Creating a date formatter is slow (about 0.1 ms) and every message in a group asks for the time several times, so each formatter is made
// once and reused. This was about three quarters of all the work the bot did for a message in a group.
const formatters = new Map();
function formatter(locale, timeZone, opts) {
  const key = `${locale}|${timeZone}|${JSON.stringify(opts)}`;
  let f = formatters.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat(locale, { timeZone, ...opts });
    formatters.set(key, f);
  }
  return f;
}

const known = new Map(); // zone name -> is it a real time zone
function zone() {
  const z = saved() || process.env.TIMEZONE || config.timezone || 'Africa/Johannesburg';
  let ok = known.get(z);
  if (ok === undefined) {
    try {
      new Intl.DateTimeFormat('en-GB', { timeZone: z });
      ok = true;
    } catch (err) {
      ok = false;
    }
    known.set(z, ok);
  }
  return ok ? z : 'UTC';
}

function parts(date = new Date()) {
  const timeZone = zone();
  const fmt = (locale, opts) => formatter(locale, timeZone, opts).format(date);
  return {
    zone: timeZone,
    time: fmt('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
    day: fmt('en-GB', { weekday: 'long' }),
    date: fmt('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    hhmm: fmt('en-GB', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }),
    dom: Number(fmt('en-GB', { day: 'numeric' })), // day of the month
    y: Number(fmt('en-GB', { year: 'numeric' })),
    mo: Number(fmt('en-GB', { month: 'numeric' })),
    dow: fmt('en-GB', { weekday: 'short' }).toLowerCase().slice(0, 3), // mon, tue...
  };
}

// "6:30" -> "06:30", anything invalid -> null
function parseHHMM(text) {
  const m = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(String(text || '').trim());
  return m ? `${m[1].padStart(2, '0')}:${m[2]}` : null;
}

// 3725 seconds -> "1h 2m"
function uptime(seconds = process.uptime()) {
  const s = Math.floor(seconds);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d) return `${d}d ${h}h ${m}m`;
  if (h) return `${h}h ${m}m`;
  return `${m}m ${s % 60}s`;
}

// "2026-10" for the month a timestamp falls in (in the bot's time zone)
function monthOf(ts = Date.now()) {
  return formatter('en-CA', zone(), { year: 'numeric', month: '2-digit' }).format(new Date(ts));
}

// "Oct 2026"
function monthLabel(ts = Date.now()) {
  return formatter('en-GB', zone(), { month: 'short', year: 'numeric' }).format(new Date(ts));
}

// "3 Oct"
function shortDate(ts) {
  return formatter('en-GB', zone(), { day: 'numeric', month: 'short' }).format(new Date(ts));
}

// 5400000 -> "1h 30m"
function duration(ms) {
  const m = Math.max(0, Math.floor(ms / 60000));
  if (m < 1) return 'less than a minute';
  const d = Math.floor(m / 1440);
  const h = Math.floor((m % 1440) / 60);
  if (d) return `${d}d ${h}h`;
  if (h) return `${h}h ${m % 60}m`;
  return `${m}m`;
}

// "3 Oct, 18:30"
function stamp(ts) {
  const d = new Date(ts);
  const day = formatter('en-GB', zone(), { day: 'numeric', month: 'short' }).format(d);
  const time = formatter('en-GB', zone(), { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d);
  return `${day}, ${time}`;
}

module.exports = { zone, parts, parseHHMM, uptime, monthOf, monthLabel, shortDate, duration, stamp };
