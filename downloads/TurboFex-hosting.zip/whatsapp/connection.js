const fs = require('fs');
const path = require('path');
const pino = require('pino');
const qrcode = require('qrcode-terminal');
const baileys = require('../core/baileys');
const config = require('../config');
const brand = require('../core/brand');
const scheduler = require('../core/scheduler');
const meta = require('./metadata');
const { withTimeout } = require('./timeout');
const { handleMessage, diag, isKnownCommand } = require('./handler');
const { handleParticipants } = require('./events');
const sent = require('./sent');
const outbox = require('./outbox');
const idmap = require('./idmap');
const watchers = require('./watchers');
const store = require('./store');
const { getText, isCommandText } = require('./utils');
const startup = require('./startup');
const updatewatch = require('./updatewatch');
const ack = require('./ack');
const { makeCache } = require('../core/cache');
const { fastKeys } = require('../core/fastkeys');
const pairfix = require('../core/pairfix');
const sessionBackup = require('../core/sessionbackup');
const linkpreview = require('../core/linkpreview');
const names = require('./names');
const mentions = require('./mentions');
const presence = require('./presence');
const adminguard = require('./adminguard');
const { flushAll } = require('../core/flush');
const perf = require('./perf');
const placeholder = require('../core/placeholder');
const replay = require('./replay');
const welcome = require('./welcome');
const status = require('./status');
const setup = require('../core/setup');
const sessionid = require('../core/sessionid');
const { DATA } = require('../core/paths');

let generation = 0; // only the newest connection may do anything
let current = null;
let reconnectTimer = null;
let attempts = 0; // failed connection attempts in a row (the wait between attempts grows, so we never hammer WhatsApp)
let watchdog = null;
const chatqueue = require('../core/chatqueue');
const backoff = require('../core/backoff');
const chatQueues = chatqueue.createQueues(); // one line of waiting messages per chat

const FRESH_SECONDS = 120; // a message that arrived while the bot was reconnecting is still answered if it is this young

// how the bot shows up in Linked devices (it is fixed when the bot is LINKED). The default is 'android': WhatsApp sends view-once
// files only to a device linked like the Android app. BOT_BROWSER=web (or macos / windows) switches back to a browser identity.
function pickBrowser(Browsers) {
  const want = String(store.getBrowser() || config.browser || 'android').toLowerCase();
  if (want === 'android') {
    const a = Browsers.android;
    try {
      if (typeof a === 'function') return a('13'); // the argument is the Android version number (the library's own example uses '13'); the browser name inside stays Chrome, which pairing codes need
      if (Array.isArray(a)) return a;
    } catch (err) {
      // fall through
    }
    console.log('⚠️ This WhatsApp library has no "android" identity. Using the default one.');
  }
  if (want === 'macos' && Browsers.macOS) return Browsers.macOS('Desktop');
  if (want === 'windows' && Browsers.windows) return Browsers.windows('Chrome');
  return Browsers.ubuntu('Chrome');
}

// Checks every minute that WhatsApp still answers. A connection can die silently (the bot looks online but hears
// nothing): that is the "bot sleeps" problem. Two missed answers in a row = reconnect at once.
function startWatchdog(sock, alive) {
  stopWatchdog();
  let misses = 0;
  watchdog = setInterval(async () => {
    if (!alive()) return stopWatchdog();
    try {
      await withTimeout(
        sock.query({ tag: 'iq', attrs: { to: 's.whatsapp.net', type: 'get', xmlns: 'w:p' }, content: [{ tag: 'ping', attrs: {} }] }),
        30000,
        'ping timed out'
      );
      misses = 0;
    } catch (err) {
      misses += 1;
      console.log(`⚠️ WhatsApp did not answer a health check (${misses}/3): ${err.message}`);
      if (misses >= 3) { // every reconnect makes WhatsApp show "Finished syncing" on the phone, so only a really dead connection is reconnected
        misses = 0;
        console.log('🔌 The connection stopped answering. Reconnecting...');
        try {
          sock.end(new Error('Watchdog: connection stopped answering'));
        } catch (e) {
          // already closed
        }
      }
    }
  }, 60000);
  if (watchdog.unref) watchdog.unref();
}

function stopWatchdog() {
  if (watchdog) clearInterval(watchdog);
  watchdog = null;
}

const isFresh = (msg) => {
  const ts = replay.timestampOf(msg);
  return ts > 0 && Date.now() / 1000 - ts < FRESH_SECONDS;
};

// messages of ONE chat are handled in order, different chats never wait for each other (core/chatqueue.js: the line has a limit)
let lastDropNote = 0;
function enqueue(jid, task) {
  const dropped = chatQueues.enqueue(jid, task);
  if (dropped && Date.now() - lastDropNote > 60000) {
    lastDropNote = Date.now();
    console.log(`⚠️ A chat is sending messages faster than the bot can handle them. ${dropped} old waiting message(s) were skipped (the newest ${chatqueue.MAX_WAITING} are kept).`);
  }
}

const closeTimes = []; // when the connection closed (last hour)

// Writes a line to the console when the bot froze for a few seconds (a frozen bot cannot answer WhatsApp and gets disconnected)
let lagTimer = null;
function startLagWatch() {
  if (lagTimer) return;
  let last = Date.now();
  lagTimer = setInterval(() => {
    const now = Date.now();
    const late = now - last - 1000;
    last = now;
    if (late > 5000) console.log(`⏱️ The bot was frozen for about ${Math.round(late / 1000)} seconds (heavy work). A long freeze can make WhatsApp drop the connection.`);
  }, 1000);
  if (lagTimer.unref) lagTimer.unref();
}

// Starts the connection after `delay`. When the START itself fails (a disk error, too many open files...) it tries again and again
// with a growing wait (core/backoff.js). Before, two failed starts in a row left the bot offline for good with nothing left to retry.
let startFailures = 0;
function scheduleStart(delay) {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(() => {
    startWhatsApp().then(() => {
      startFailures = 0;
    }).catch((e) => {
      startFailures += 1;
      const wait = backoff.delayAfter(startFailures);
      console.error(`Reconnect failed (${startFailures} in a row): ${e && e.message}. Trying again in ${Math.round(wait / 1000)}s...`);
      scheduleStart(wait);
    });
  }, delay);
}

async function startWhatsApp() {
  const lib = await baileys.load(); // works with the old and the new library version
  const { makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers } = lib;
  const cacheKeys = lib.makeCacheableSignalKeyStore || ((keys) => keys); // keeps encryption keys in memory (much faster on slow disks)

  const gen = ++generation;
  clearTimeout(reconnectTimer);
  stopWatchdog();
  try { require('./warm').stop(); } catch (err) { /* never a reason to fail */ }
  // never keep two connections open (two copies fight each other and cause "Bad MAC")
  if (current) {
    try {
      current.ev.removeAllListeners();
      current.end(undefined);
    } catch (err) {
      // already closed
    }
    current = null;
  }

  try {
    sessionBackup.restoreIfNeeded(config.sessionDir); // a damaged login is restored from the last backup
  } catch (err) {
    console.error('Login restore failed:', err.message);
  }
  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
  if (gen !== generation) return;

  // No login: the pairing site is the way to get one (the console shows what to do and nothing is asked)
  if (!state.creds.registered && !config.consoleLink) {
    setup.waitForSession(config, 'none');
    return;
  }

  const logger = pino({ level: 'silent' });

  // While linking, ask for the CURRENT WhatsApp Web version: an outdated one makes WhatsApp refuse the link
  let versionOpt = {};
  if (!state.creds.registered) {
    try {
      const fetcher = lib.fetchLatestWaWebVersion || lib.fetchLatestBaileysVersion;
      const found = fetcher ? await withTimeout(fetcher(), 10000, 'version lookup timed out') : null;
      if (found && Array.isArray(found.version)) {
        versionOpt = { version: found.version };
        console.log(`WhatsApp Web version used for linking: ${found.version.join('.')}`);
      }
    } catch (err) {
      console.log('Could not look up the current WhatsApp Web version, using the built-in one.');
    }
  }

  const sock = makeWASocket({
    auth: { creds: state.creds, keys: cacheKeys(fastKeys(state.keys), logger) },
    logger,
    ...versionOpt,
    browser: pickBrowser(Browsers),
    markOnlineOnConnect: false,
    syncFullHistory: false,
    // The library closes the connection when WhatsApp was silent for this time + 5 seconds. A busy bot (many groups, big saves,
    // pictures being made) can freeze for a few seconds: with 25 seconds that was taken for a dead connection, the bot reconnected
    // and the phone showed "Finished syncing" again and again. 45 seconds leaves room; the watchdog below still finds a really dead line.
    keepAliveIntervalMs: 45000,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 60000,
    getMessage: async (key) => outbox.get(key), // lets WhatsApp ask for a message again ("Waiting for this message" fix)
    userDevicesCache: makeCache(3 * 3600 * 1000), // who has which devices: remembered for 3 hours; the chats in use are refreshed every 15 minutes (whatsapp/warm.js), so the first reply after a break is not slow
    msgRetryCounterCache: makeCache(10 * 60 * 1000),
    // stops the library from asking the phone to resend every message it cannot decrypt: each request makes the phone show
    // "Finished syncing with WhatsApp on Google Chrome (Ubuntu)" (see core/placeholder.js)
    placeholderResendCache: placeholder.cache,
    cachedGroupMetadata: async (jid) => {
      const t = Date.now();
      try {
        return await meta.getMeta(sock, jid);
      } finally {
        perf.metaMs += Date.now() - t;
      }
    },
    getUrlInfo: (text) => (store.getLinkPreview() ? linkpreview.getUrlInfo(text, {}, sock.waUploadToServer) : undefined), // link previews (see core/linkpreview.js)
    emitOwnEvents: false, // our own replies do not need to come back as incoming events
  });
  current = sock;
  const alive = () => gen === generation;
  const linking = pairfix.install(sock); // lets a new device link again (see core/pairfix.js)
  let qrFallback = false; // a pairing code was chosen but WhatsApp refused it: the QR is shown instead
  let latestQr = null;
  const showQr = (raw) => {
    latestQr = raw;
    if (config.pairMethod === 'code' && !qrFallback) return; // the person chose a pairing code: no QR
    console.log('\n==============================================');
    console.log('  LINK THE BOT: WhatsApp > Linked devices >');
    console.log('  Link a device, then SCAN this QR code with the phone.');
    console.log('  If WhatsApp asks again, a NEW QR appears: scan it too.');
    console.log('==============================================\n');
    qrcode.generate(raw, { small: true });
  };
  linking.onRefresh(showQr);
  // WhatsApp answers a pairing-code request with an error when it refuses it; the library shows a code anyway
  let lastIqError = null;
  if (sock.ws && typeof sock.ws.on === 'function') {
    sock.ws.on('CB:iq,type:error', (node) => {
      const e = Array.isArray(node && node.content) ? node.content.find((c) => c && c.tag === 'error') : null;
      lastIqError = { at: Date.now(), code: e && e.attrs && e.attrs.code, text: e && e.attrs && e.attrs.text };
    });
  }
  ack.installStatusAck(sock); // stops WhatsApp from cutting the connection about every 50 minutes

  // remember the ids of our own replies so we never answer ourselves
  const rawSend = sock.sendMessage.bind(sock);
  sock.sendMessage = async (...args) => {
    // a private chat is addressed the way WhatsApp itself addresses that person (LID when known). Messages sent to
    // the phone number of such a person show "Waiting for this message" on many phones.
    if (typeof args[0] === 'string' && args[0].endsWith('@s.whatsapp.net') && !args[2]?.statusJidList) {
      args[0] = idmap.lidSync(args[0]) || args[0];
    }
    // tags in groups use the id the group uses, so WhatsApp shows the person's NAME instead of a number
    if (typeof args[0] === 'string' && args[0].endsWith('@g.us') && Array.isArray(args[1]?.mentions) && args[1].mentions.length) {
      args[1] = await mentions.fix(sock, args[0], args[1]);
    } else if (typeof args[0] === 'string' && !args[0].endsWith('@g.us') && !args[0].endsWith('@broadcast') && Array.isArray(args[1]?.mentions) && args[1].mentions.length) {
      args[1] = mentions.inPrivate(args[1]); // a private chat shows a tag as a bare number: write the name instead
    }
    // a message with a link gets a link preview (the card with picture and title)
    const content = args[1];
    if (content && typeof content.text === 'string' && content.linkPreview === undefined && !content.edit && store.getLinkPreview()) {
      const info = await linkpreview.getUrlInfo(content.text, {}, sock.waUploadToServer);
      if (info) args[1] = { ...content, linkPreview: info };
    }
    perf.metaMs = 0;
    const t0 = Date.now();
    const res = await rawSend(...args);
    perf.lastSendMs = Date.now() - t0;
    perf.lastMetaMs = perf.metaMs;
    if (res?.key?.id) sent.remember(res.key.id);
    outbox.remember(res);
    return res;
  };

  sock.ev.on('creds.update', () => {
    if (alive()) Promise.resolve(saveCreds()).catch((e) => console.error('Could not save the login:', e.message));
  });

  let pairingAsked = false;
  let invalidLogin = false;

  sock.ev.on('connection.update', async (update) => {
    if (!alive()) return;
    const { connection, lastDisconnect, qr } = update;

    if (qr && !config.consoleLink) {
      // WhatsApp wants a NEW link (the saved login is not accepted). Linking happens on the pairing site, not here.
      if (!invalidLogin) {
        invalidLogin = true;
        try {
          sock.ev.removeAllListeners();
          sock.end(undefined);
        } catch (err) {
          // already closed
        }
        current = null;
        stopWatchdog();
        try { require('./warm').stop(); } catch (err) { /* never a reason to fail */ }
        scheduler.stop();
        sessionid.forget();
        setup.waitForSession(config, 'invalid');
      }
      return;
    }

    if (qr) {
      showQr(linking.fixQr(qr)); // the QR is always shown

      // the pairing code (unless the person chose the QR code), once per attempt
      if (config.pairingNumber && config.pairMethod !== 'qr' && !pairingAsked && !sock.authState.creds.registered) {
        pairingAsked = true;
        const asked = Date.now();
        try {
          const raw = await sock.requestPairingCode(config.pairingNumber);
          await new Promise((r) => setTimeout(r, 3000)); // WhatsApp's answer arrives a moment after the code is made
          if (lastIqError && lastIqError.at >= asked - 500) {
            console.log(`\n⚠️ WhatsApp REFUSED the pairing code request (${lastIqError.code || '?'} ${lastIqError.text || ''}).`);
            console.log('   Codes are refused by WhatsApp at the moment. Here is the QR code instead, scan it:\n');
            qrFallback = true;
            if (latestQr) showQr(latestQr);
          } else {
            const code = raw?.match(/.{1,4}/g)?.join('-') || raw;
            console.log('\n==============================================');
            console.log(`  PAIRING CODE:  ${code}`);
            console.log('  WhatsApp > Linked devices > Link a device >');
            console.log('  "Link with phone number instead" > enter the code');
            console.log('==============================================\n');
          }
        } catch (err) {
          console.log('Could not get a pairing code:', err.message, '- here is the QR code instead:');
          qrFallback = true;
          if (latestQr) showQr(latestQr);
        }
      }
    }

    if (connection === 'open') {
      require('../core/chatlog').banner(`${brand.botName} is online as ${sock.user?.id}`);
      scheduler.start(sock);
      Promise.resolve()
        .then(() => require('../core/plugins').start(sock))
        .catch((err) => console.error('Plugins could not start:', err.message));
      try {
        require('./captcha').resume(sock); // open verification questions continue after a restart or reconnect
      } catch (err) {
        console.error('Could not resume the verification questions:', err.message);
      }
      presence.apply(sock); // always online / auto bio
      replay.open(); // for a few seconds, skip old messages WhatsApp re-delivers
      startWatchdog(sock, alive);
      startLagWatch();
      sessionBackup.schedule(config.sessionDir); // daily login backup, monthly cleanup
      const stable = setTimeout(() => {
        if (alive()) attempts = 0; // connected for a while: forget earlier failures
      }, 30000);
      if (stable.unref) stable.unref();

      // load the group list as early as possible, so the first command in a group never waits for WhatsApp (that wait is what made the
      // first reply in a group slow). If it fails it is tried again 5, 15 and 45 seconds later; before, one failure meant every group
      // was loaded one by one, by the first person to write in it.
      const primeGroups = async (tryNo) => {
        if (!alive()) return;
        try {
          const all = await withTimeout(sock.groupFetchAllParticipating(), 30000, 'group list timed out');
          meta.prime(all);
        } catch (err) {
          if (tryNo < 3 && alive()) {
            const again = setTimeout(() => primeGroups(tryNo + 1), 5000 * 3 ** tryNo);
            if (again.unref) again.unref();
          }
        }
      };
      const firstPrime = setTimeout(() => primeGroups(0), 1000);
      if (firstPrime.unref) firstPrime.unref();
      require('./warm').start(sock); // keeps the device lists of the chats in use fresh (the first ping after a break stays fast)
      // get the downloader ready in the background, so the first download after a start does not have to find it first
      const warm = setTimeout(() => { try { require('../core/ytdlp').warmUp(); } catch (err) { /* only a speed-up */ } }, 8000);
      if (warm.unref) warm.unref();

      updatewatch.start(sock, alive); // tells the owner when a new version is out, and what changed
      // an update that was just installed leaves a marker: turn it into an "update complete" note (once)
      startup.noteFromUpdateMarker();
      // the first time an account connects it gets a welcome message; after a restart or update it gets a short "I am back" message
      setTimeout(async () => {
        if (!alive()) return;
        try {
          await welcome.maybeSendWelcome(sock);
        } catch (e) {
          console.error('Welcome message error:', e.message);
        }
        try {
          if (alive()) await startup.announce(sock);
        } catch (e) {
          console.error('Restart message error:', e.message);
        }
      }, welcome.settings.delayMs);
      // The bot started fine, so a fresh update does not need to be rolled back
      try {
        fs.rmSync(path.join(DATA, 'rollback', 'pending'), { force: true });
      } catch (err) {
        // ignore
      }
    }

    if (connection === 'close') {
      updatewatch.stop();
      scheduler.stop();
      try {
        require('../core/plugins').stop();
      } catch (err) {
        // not important
      }
      stopWatchdog();
      const status = lastDisconnect?.error?.output?.statusCode;
      let delay;
      attempts += 1;
      // Every new connection makes the phone show "Finished syncing with WhatsApp on Google Chrome (Ubuntu)". Count them, so a
      // reconnect loop (a bad network, or a second copy of the bot using the same number) is easy to see.
      const nowMs = Date.now();
      closeTimes.push(nowMs);
      while (closeTimes.length && nowMs - closeTimes[0] > 60 * 60 * 1000) closeTimes.shift();
      if (closeTimes.length >= 3) console.log(`📶 ${closeTimes.length} disconnects in the last hour (latest code ${status}). Each reconnect makes WhatsApp show "Finished syncing" on your phone. Check the network, and make sure only ONE copy of the bot uses this number.`);
      if (status === DisconnectReason.loggedOut) {
        console.log('Logged out of WhatsApp. Clearing saved login, starting fresh...');
        sessionBackup.markLoggedOut(); // the backups are no longer valid
        fs.rmSync(config.sessionDir, { recursive: true, force: true });
        attempts = 0;
        delay = 3000;
        if (!config.consoleLink) {
          sessionid.forget(); // that session ID is finished: a NEW one is needed
          setup.waitForSession(config, 'logged-out');
          return;
        }
      } else if (status === DisconnectReason.connectionReplaced) {
        // another copy of the bot is using this number. Fighting it makes both copies reconnect forever and makes
        // WhatsApp send the "Finished syncing" notification again and again, so wait longer each time.
        delay = Math.min(300000, 30000 * 2 ** Math.min(attempts - 1, 3));
        console.log(`⚠️ This WhatsApp number was opened somewhere else (another copy of the bot?). Make sure only ONE copy is running. Trying again in ${Math.round(delay / 1000)}s.`);
      } else if (status === DisconnectReason.restartRequired) {
        attempts = 0;
        delay = 500; // normal after linking: reconnect straight away
        console.log('Reconnecting after WhatsApp asked for a restart...');
      } else {
        delay = Math.min(30000, 2000 * 2 ** Math.min(attempts - 1, 4)) + Math.random() * 1000;
        console.log(`Connection closed (code ${status}). Reconnecting in ${Math.round(delay / 1000)}s...`);
      }
      scheduleStart(delay);
    }
  });

  sock.ev.on('messages.upsert', ({ messages, type }) => {
    if (!alive()) return;
    const prefix = store.effectivePrefix();
    for (const msg of messages) {
      // WhatsApp statuses (auto view / like / save)
      if (msg.key.remoteJid === 'status@broadcast') {
        status.handleStatus(sock, msg).catch((e) => console.error('Status error:', e.message));
        continue;
      }
      // 'append' = messages that were waiting while the bot reconnected. Fresh ones are still answered (before, they were dropped).
      if (type !== 'notify' && !(type === 'append' && !msg.key.fromMe && isFresh(msg))) continue;
      if (replay.isReplay(msg)) {
        diag.stats.replaysIgnored += 1;
        continue;
      }
      if (!msg.key.fromMe) watchers.early(sock, msg); // view-once files never wait in the chat's line (the handler's own call finds it already done)
      const run = async () => {
        try {
          await withTimeout(handleMessage(sock, msg), 60000, 'Handling a message took too long');
        } catch (err) {
          console.error('Message error:', err);
        }
      };
      // commands never wait for other messages; everything else (game answers...) stays in order per chat
      if (isCommandText(getText(msg), prefix, isKnownCommand)) run();
      else enqueue(msg.key.remoteJid || 'unknown', run);
    }
  });

  // edits and deletions that WhatsApp reports as updates
  sock.ev.on('messages.update', (updates) => {
    if (!alive()) return;
    watchers.onUpdate(sock, updates).catch((e) => console.error('Update watcher error:', e.message));
  });

  // learn which phone number belongs to which hidden id
  const learn = (list) => {
    try {
      idmap.learnContacts(list);
      names.learnContacts(list);
    } catch (err) {
      // not important
    }
  };
  sock.ev.on('contacts.upsert', (list) => alive() && learn(list));
  sock.ev.on('contacts.update', (list) => alive() && learn(list));
  sock.ev.on('lid-mapping.update', (m) => alive() && idmap.learn(m?.lid, m?.pn));

  sock.ev.on('group-participants.update', async (update) => {
    if (!alive()) return;
    try {
      const ev = update.action === 'add' ? 'member.join' : update.action === 'remove' ? 'member.leave' : update.action === 'promote' ? 'member.promote' : update.action === 'demote' ? 'member.demote' : '';
      if (ev) require('../core/plugins').emit(ev, { sock, jid: update.id, members: update.participants }); // plugins that listen to joins and leaves
    } catch (err) {
      // a plugin problem never stops the group event
    }
    try {
      await handleParticipants(sock, update);
    } catch (err) {
      console.error('Group event error:', err);
    }
  });

  sock.ev.on('call', (calls) => {
    if (alive()) adminguard.handleCalls(sock, calls).catch((e) => console.error('Call handler error:', e.message));
  });

  sock.ev.on('groups.update', (updates) => {
    if (!alive()) return;
    // the group's name, description and settings are updated in the saved group info (no refetch, no waiting)
    for (const u of updates || []) if (u.id && !meta.patch(u.id, u)) meta.invalidate(u.id);
  });
}

// when the host stops the bot, write the saved changes to disk first
for (const sig of ['SIGTERM', 'SIGINT']) {
  process.once(sig, () => {
    flushAll().finally(() => process.exit(0));
    setTimeout(() => process.exit(0), 5000).unref();
  });
}

module.exports = { startWhatsApp };
