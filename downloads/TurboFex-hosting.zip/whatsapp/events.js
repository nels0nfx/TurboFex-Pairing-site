const store = require('./store');
const meta = require('./metadata');
const replay = require('./replay');
const joined = require('./joined');
const { num } = require('./utils');
const adminguard = require('./adminguard');
const captcha = require('./captcha');
const welcomedm = require('./welcomedm');
const intro = require('./intro');

const recent = new Map();

// WhatsApp can deliver the same group event twice
function isDuplicate(update) {
  const ids = (update.participants || []).map((p) => (typeof p === 'string' ? p : p?.id)).sort().join(',');
  const key = `${update.id}|${update.action}|${ids}`;
  const now = Date.now();
  if (now - (recent.get(key) || 0) < 30000) return true;
  recent.set(key, now);
  if (recent.size > 500) recent.clear();
  return false;
}

// Fills in @user, {group} and {count} in the saved message
function render(template, jid, name, count) {
  return template
    .replace(/@user/gi, () => `@${num(jid)}`)
    .replace(/\{group\}/gi, () => name)
    .replace(/\{count\}/gi, () => String(count ?? ''));
}

// Runs when people join, leave, or are promoted / demoted
async function handleParticipants(sock, update) {
  const { id, participants, action, author } = update;
  if (!meta.applyParticipants(id, action, participants)) meta.invalidate(id);
  if (isDuplicate(update)) return;
  // events WhatsApp replays right after (re)connecting are old news: no greetings for them
  const stale = replay.inWindow();

  const g = store.getGroup(id);
  const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(num);
  const ids = (participants || [])
    .map((p) => (typeof p === 'string' ? p : p?.id))
    .filter(Boolean)
    .filter((j) => !botIds.includes(num(j)));
  if (!ids.length) return;

  // Protection against take-overs: unauthorised promotions / demotions are undone
  if ((action === 'promote' || action === 'demote') && !stale) adminguard.guardAdmins(sock, id, action, ids, author).catch((e) => console.error('Admin guard error:', e.message));

  // Promote / demote notices
  if (action === 'promote' || action === 'demote') {
    if (!g.pdm || stale) return;
    const by = author ? ` by @${num(author)}` : '';
    const text = ids
      .map((j) => `${action === 'promote' ? '👑' : '⬇️'} @${num(j)} was ${action === 'promote' ? 'promoted to admin' : 'demoted'}${by}.`)
      .join('\n');
    return sock.sendMessage(id, { text, mentions: [...ids, ...(author ? [author] : [])] });
  }

  if (action !== 'add' && action !== 'remove') return;
  if (!stale) {
    // for newmembers: remember who joined and when (and forget who left)
    if (action === 'add') joined.record(id, ids);
    else joined.forget(id, ids);
  }
  if (action === 'add' && !stale) {
    captcha.onRaid(sock, id, ids, g).catch((e) => console.error('Raid protection error:', e.message)); // many joins at once
    captcha.onJoin(sock, id, ids, g).catch((e) => console.error('Verification error:', e.message)); // a question for every new member
  }

  let removed = [];
  if (action === 'add' && g.antifake.length) {
    // Anti-fake: only numbers starting with the allowed country codes may join
    const bad = ids.filter(
      (j) => j.endsWith('@s.whatsapp.net') && !g.antifake.some((p) => num(j).startsWith(p))
    );
    if (bad.length) {
      try {
        await sock.groupParticipantsUpdate(id, bad, 'remove');
        removed = bad;
        meta.invalidate(id);
        await sock.sendMessage(id, {
          text: `🚫 Removed ${bad.map((j) => '@' + num(j)).join(' ')}: numbers from other countries are not allowed here.`,
          mentions: bad,
        });
      } catch (err) {
        // the bot is not an admin, nothing we can do
      }
    }
  }

  if (action === 'add' && !stale) welcomedm.send(sock, id, ids.filter((x) => !removed.includes(x))).catch((e) => console.error('Private welcome error:', e.message));
  // the introduction goes out for new members when it is ON, also when the welcome message is OFF
  // (with the verification ON it waits until the new member has answered the sum: see captcha.js)
  const introNow = action === 'add' && !stale && g.intro.on && !g.captcha;
  if (action === 'add' && (!g.welcome || stale) && !introNow) return;
  if (action === 'remove' && (!g.goodbye || stale)) return;

  let info = null;
  try {
    info = await meta.getMeta(sock, id);
  } catch (err) {
    info = null;
  }
  const name = info?.subject || 'the group';
  const count = info?.participants?.length;
  const template =
    action === 'add'
      ? g.welcomeText || store.DEFAULT_WELCOME
      : g.goodbyeText || store.DEFAULT_GOODBYE;

  const people = ids.filter((x) => !removed.includes(x));
  if (action === 'remove' || (g.welcome && !stale)) {
    for (const j of people) {
      await sock.sendMessage(id, { text: render(template, j, name, count), mentions: [j] });
    }
  }
  // the introduction follows the welcome message
  if (introNow && people.length) await intro.send(sock, id, people, name, count, g.intro).catch((e) => console.error('Introduction error:', e.message));
}

module.exports = { handleParticipants };
