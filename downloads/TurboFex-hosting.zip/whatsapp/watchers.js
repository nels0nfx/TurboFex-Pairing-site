// Auto view-once, anti-delete and anti-edit. Each has a mode (off / all / dm / group) and its own destination chat.
const store = require('./store');
const placeholder = require('../core/placeholder');
const cache = require('./msgcache');
const meta = require('./metadata');
const clock = require('../core/clock');
const media = require('./media');
const { ownerChat, normalize } = require('./owner');
const { num } = require('./utils');
const { peel, textOf, findViewOnce, editInfo } = require('./unwrap');
const { withTimeout } = require('./timeout');
const secretedit = require('./secretedit');
const vault = require('./vovault');

const MAX_MEDIA = 2 * 1024 * 1024;
let downloading = 0; // never more than 2 downloads at once (many pictures in a busy group would slow everything) // pictures/videos bigger than this are not kept for anti-delete

// shown by !status
const stats = { editSecret: 0, editUnreadable: 0, editEvents: 0, deleteEvents: 0, viewOnce: 0, viewOnceSaved: 0, deleted: 0, edited: 0, errors: 0, lastError: null };

// where a copy goes: the chosen chat, "chat" = the chat where it happened (deleted, edited or sent), else the owner's own chat
function dest(sock, cfg, chatJid) {
  if (cfg.to === 'chat' && chatJid) return chatJid;
  return normalize(sock, cfg.to !== 'chat' ? cfg.to : null) || ownerChat(sock);
}

const inScope = (mode, isGroup) => mode === 'all' || (mode === 'dm' && !isGroup) || (mode === 'group' && isGroup);
const typeIs = (t, number, name) => t === number || t === name;
// these notices go to the owner's private chat: a tag there shows the person's name (or number); see mentions.inPrivate
const tagOf = (jid) => `@${num(jid)}`;
const handled = new Map(); // finished deletions / edits (the same event can arrive twice)

function once(key) {
  const now = Date.now();
  if (now - (handled.get(key) || 0) < 60000) return false;
  handled.set(key, now);
  if (handled.size > 2000) handled.clear();
  return true;
}

async function chatName(sock, jid) {
  if (!jid.endsWith('@g.us')) return 'a private chat';
  try {
    return `the group "${(await meta.getMeta(sock, jid)).subject}"`;
  } catch (err) {
    return 'a group';
  }
}

function kindName(message) {
  const { content: m } = peel(message);
  if (m.imageMessage) return 'picture';
  if (m.videoMessage) return 'video';
  if (m.audioMessage) return m.audioMessage.ptt ? 'voice note' : 'audio';
  if (m.stickerMessage) return 'sticker';
  if (m.documentMessage) return 'document';
  return null;
}

// the original message as a "reply", so the copy points back to the chat it came from
function quotedOriginal(item, id) {
  const group = String(item.jid).endsWith('@g.us');
  return {
    key: { remoteJid: item.jid, fromMe: false, id, ...(group ? { participant: item.sender } : {}) },
    message: item.message || { conversation: item.text || '' },
  };
}

async function sendCopy(sock, to, item, header, quoted) {
  const caption = `${header}${item.text ? `\n\n${item.text}` : ''}`;
  const mentions = [...new Set([item.sender, ...(item.mentions || [])].filter(Boolean))];
  const opts = quoted ? { quoted } : undefined;
  if (item.kind === 'text') return sock.sendMessage(to, { text: `${header}\n\n${item.text || ''}`, mentions }, opts); // a view-once text: there is no file
  if (item.buffer && item.kind) {
    // WhatsApp sent a small preview, the size and the length along with the original. Handing them over means the library does not have to make
    // them itself, which is slow on a weak host (resizing a big picture, or starting ffmpeg for a video) and delayed every copy.
    const thumb = item.thumb && item.thumb.length ? { jpegThumbnail: Buffer.from(item.thumb) } : {};
    const size = item.width && item.height ? { width: item.width, height: item.height } : {};
    if (item.kind === 'picture') return sock.sendMessage(to, { image: item.buffer, caption, mentions, ...thumb, ...size }, opts);
    if (item.kind === 'video') return sock.sendMessage(to, { video: item.buffer, caption, mentions, ...thumb, ...size, ...(item.seconds ? { seconds: item.seconds } : {}) }, opts);
    if (item.kind === 'sticker') {
      await sock.sendMessage(to, { text: header, mentions }, opts);
      return sock.sendMessage(to, { sticker: item.buffer });
    }
    if (item.kind === 'voice note' || item.kind === 'audio') {
      await sock.sendMessage(to, { text: header, mentions }, opts);
      return sock.sendMessage(to, { audio: item.buffer, mimetype: item.mime || 'audio/ogg; codecs=opus', ptt: item.kind === 'voice note' });
    }
  }
  const note = item.kind ? `\n(the ${item.kind} was too big or could not be saved)` : '';
  return sock.sendMessage(to, { text: `${caption}${note}`, mentions }, opts);
}

// when something fails the owner is told, instead of silence (at most once a minute per kind of problem)
const lastWarn = new Map();
async function warnOwner(sock, text, kind = 'general', mentions = []) {
  const every = kind === 'empty' ? 6 * 3600 * 1000 : 60000; // "no content" can happen for many reasons, so it is only said now and then
  if (Date.now() - (lastWarn.get(kind) || 0) < every) return;
  lastWarn.set(kind, Date.now());
  try {
    await sock.sendMessage(ownerChat(sock), { text, mentions });
  } catch (err) {
    // nothing more we can do
  }
}

function problem(what, err) {
  stats.errors += 1;
  stats.lastError = `${what}: ${String(err?.message || err).slice(0, 80)}`;
  console.error(`${what} failed:`, err?.message || err);
}

// downloads a file: a second try after a moment, then a third with a fresh link asked from WhatsApp
async function fetchMedia(sock, source) {
  try {
    return await media.download(sock, source);
  } catch (err) {
    if (err.code === 'TOO_BIG') throw err;
    await new Promise((r) => setTimeout(r, 500)); // a failed first download is usually a blip: try again soon (it waited 1.5 s)
    try {
      return await media.download(sock, source);
    } catch (err2) {
      if (typeof sock.updateMediaMessage === 'function') {
        try {
          const fresh = await withTimeout(Promise.resolve(sock.updateMediaMessage(source)), 15000, 'WhatsApp did not give a new link');
          return await media.download(sock, fresh || source);
        } catch (err3) {
          // the first reason is the useful one
        }
      }
      throw err2;
    }
  }
}

const OPEN_ON_PHONE =
  'WhatsApp only gives view-once files to the phone itself, not to linked devices like this bot.\n' +
  '💡 Reply to the view-once message with *vv* to open it.';

// ---------------------------------------------------------------- view once
// The same view-once message can reach the bot twice: first WITHOUT its file (a placeholder), then again, complete, with the
// same id (after the bot asked the phone for it, or after a reconnect). The second one used to be thrown away as a "duplicate"
// before the watcher saw it, so nothing was ever opened. Now the view-once watcher is called BEFORE that check (see early()),
// and keeps its own record: a message is only marked as done when its copy was really sent.
const voState = new Map(); // message id -> 'busy' | the time the copy was sent
const voWait = new Map(); // message id -> timer of the "no content" notice (cancelled when the complete message arrives)
const voKeep = new Map(); // message id -> { msg, at }: view-once messages seen lately, so "vv" can open them even if the reply lost the file details
const voAsked = new Map(); // message id -> timer: messages that arrived EMPTY and that we asked the phone to send again
const KEEP_MS = 30 * 60 * 1000;
const timing = { resendWait: 12000, answerWait: 20000 }; // milliseconds: how long we wait for the phone to send the file after we asked (tests make it tiny)

function keepViewOnce(msg) {
  const id = msg.key?.id;
  if (!id) return;
  voKeep.set(id, { msg: { key: msg.key, message: msg.message }, at: Date.now() });
  if (voKeep.size > 60) voKeep.delete(voKeep.keys().next().value);
}

// the full view-once message (with the file details) that arrived lately, for the "vv" command
function recentViewOnce(id) {
  const it = voKeep.get(id);
  if (!it) return null;
  if (Date.now() - it.at > KEEP_MS) {
    voKeep.delete(id);
    return null;
  }
  return it.msg;
}

// the message came without its file: ask the phone to send it again (the answer arrives as a normal message later)
async function askPhoneAgain(sock, msg) {
  if (typeof sock.requestPlaceholderResend !== 'function') return false;
  // every request makes the phone show "Finished syncing with WhatsApp on Google Chrome (Ubuntu)": only a few per hour
  if (!placeholder.allow(msg.key.id)) {
    console.log(`👁️ Did not ask the phone for message ${String(msg.key.id).slice(0, 8)}: the limit of ${placeholder.PER_HOUR} requests per hour is used (every request shows a notice on your phone).`);
    return false;
  }
  try {
    await withTimeout(Promise.resolve(sock.requestPlaceholderResend(msg.key)), 10000, 'the phone did not answer');
    stats.viewOnceAsked = (stats.viewOnceAsked || 0) + 1;
    return true;
  } catch (err) {
    console.log(`👁️ Could not ask the phone for the view-once file: ${err.message}`);
    return false;
  }
}

// copies one view-once file to the owner (see early() below); throws a clear problem when something unexpected breaks
async function viewOnce(sock, msg, isGroup, assume = false) {
  const cfg = store.watchCfg('viewonce');
  if (!inScope(cfg.mode, isGroup)) return;
  const vo = findViewOnce(msg.message, assume);
  if (!vo) return;
  const id = msg.key.id;
  if (id && voState.has(id)) return; // already copied, or being copied right now
  const jid = msg.key.remoteJid;
  const sender = isGroup ? msg.key.participant : jid;
  const kind = vo.kind === 'text' ? 'text' : vo.kind === 'image' ? 'picture' : vo.kind === 'video' ? 'video' : vo.node.ptt ? 'voice note' : 'audio';
  console.log(`👁️ View-once ${kind} from ${num(sender)} in ${jid} (content ${vo.empty ? 'MISSING' : 'present'}), sending to ${cfg.to || 'owner chat'}`);

  if (vo.empty) {
    if (id && voWait.has(id)) return; // we are already waiting for the complete message
    stats.viewOnce += 1;
    if (id) voWait.set(id, 0); // claimed at once, so a second call at the same moment does not ask the phone again
    const tell = async () => {
      if (id) voWait.delete(id);
      await warnOwner(sock, `👁️ A view-once ${kind} from ${tagOf(sender)} arrived in ${await chatName(sock, jid)}, but WhatsApp did not send its content to this device.\n${OPEN_ON_PHONE}`, 'viewonce', [sender]);
    };
    const asked = await askPhoneAgain(sock, msg);
    if (!asked || !id) return tell();
    const timer = setTimeout(() => tell().catch(() => {}), timing.resendWait); // told only if the complete message does not come
    if (timer.unref) timer.unref();
    voWait.set(id, timer);
    return;
  }

  // the complete message is here: the "no content" notice is no longer needed
  if (id && voAsked.has(id)) {
    clearTimeout(voAsked.get(id));
    voAsked.delete(id);
    console.log('👁️ The phone sent the hidden message. Opening it.');
  }
  if (id && voWait.has(id)) {
    clearTimeout(voWait.get(id));
    voWait.delete(id);
    console.log('👁️ The phone sent the missing view-once file.');
  }
  if (id) voState.set(id, 'busy');
  if (voState.size > 2000) {
    for (const [k, v] of voState) if (v !== 'busy') voState.delete(k);
  }
  stats.viewOnce += 1;
  if (vo.kind === 'text') {
    // a view-once text: the words are already here, nothing to download
    try {
      const where = await chatName(sock, jid);
      const header = `👁️ *View-once text*\n👤 From ${tagOf(sender)} in ${where}\n🕒 ${clock.stamp(Date.now())}`;
      await sendCopy(sock, dest(sock, cfg, jid), { kind: 'text', text: vo.text, sender, jid, message: msg.message }, header);
      if (id) voState.set(id, Date.now());
      stats.viewOnceSaved += 1;
    } catch (err) {
      if (id) voState.delete(id);
      throw err;
    }
    return;
  }
  try {
    const [where, buffer] = await Promise.all([
      chatName(sock, jid), // looked up while the file downloads (it used to be one after the other)
      vault.obtain(sock, msg, vo, fetchMedia).catch((err) => {
        problem('View-once download', err);
        return err;
      }),
    ]);
    if (buffer instanceof Error) {
      if (id) voState.delete(id); // a later delivery may try again
      const thumb = vo.node.jpegThumbnail;
      if (thumb && thumb.length && vo.kind === 'image') {
        // at least the small preview WhatsApp sent along
        await sock.sendMessage(dest(sock, cfg, jid), { image: Buffer.from(thumb), caption: `👁️ *View-once ${kind}* (small preview only: the full file could not be downloaded)\n👤 From ${tagOf(sender)} in ${where}` , mentions: [sender] }).catch(() => {});
      }
      return warnOwner(sock, `👁️ A view-once ${kind} from ${tagOf(sender)} arrived in ${where}, but I could not save it.\nReason: ${String(buffer.message).slice(0, 100)}\n${OPEN_ON_PHONE}`, 'viewonce', [sender]);
    }
    const header = vo.guessed
      ? `👁️ *Hidden ${kind}*\n▸ It arrived without its content, so it may have been a view-once.\n👤 From ${tagOf(sender)} in ${where}\n🕒 ${clock.stamp(Date.now())}`
      : `👁️ *View-once ${kind}*\n👤 From ${tagOf(sender)} in ${where}\n🕒 ${clock.stamp(Date.now())}`;
    await sendCopy(sock, dest(sock, cfg, jid), { kind, buffer, mime: vo.node.mimetype, text: vo.node.caption || '', sender, thumb: vo.node.jpegThumbnail, width: Number(vo.node.width) || 0, height: Number(vo.node.height) || 0, seconds: Number(vo.node.seconds) || 0 }, header);
    if (id) voState.set(id, Date.now());
    stats.viewOnceSaved += 1;
  } catch (err) {
    if (id) voState.delete(id);
    throw err;
  }
}

// A message arrived with NO content (or only envelope details). WhatsApp does this for view-once files on linked devices:
// the message is announced but its file is held back. The only way to get it is to ask the phone to send it again. The answer
// comes back as a normal message with the same id (see early(), "assume"). This used to be skipped for messages with no content
// at all, so the phone was never asked and nothing was opened.
const hiddenStub = (t) => t == null || t === 2 || t === 'CIPHERTEXT'; // 2 = could not be read; any other stub is a group event, not a file
function chaseHidden(sock, msg, jid) {
  const id = msg.key.id;
  const isGroup = jid.endsWith('@g.us');
  if (!id) return;
  const mode = store.watchCfg('viewonce').mode;
  if (!inScope(mode, isGroup)) return;
  if (voAsked.has(id)) {
    // the same message again: if we already asked, this is the phone's answer and it is STILL empty
    console.log(`👁️ Message ${id.slice(0, 8)} arrived again and is still empty (stub ${msg.messageStubType ?? 'none'}, params ${JSON.stringify(msg.messageStubParameters || [])}). The phone did not hand over the file.`);
    return;
  }
  if (voWait.has(id)) return;
  const sender = isGroup ? msg.key.participant : jid;
  console.log(`👁️ A message from ${num(sender)} came with no content (stub ${msg.messageStubType ?? 'none'}, params ${JSON.stringify(msg.messageStubParameters || [])}). Asking the phone for it (it may be a view-once).`);
  const timer = setTimeout(() => {
    voAsked.delete(id);
    console.log('👁️ The phone did not send the hidden message back. WhatsApp is not giving this view-once to this device.');
    // Many ordinary messages arrive empty (could not be decrypted yet, group events, reactions), so this is only a GUESS about a
    // view-once. It stays in the console and is NOT sent to the owner, otherwise normal chats trigger it. EMPTY_NOTICE=1 turns it on.
    if (process.env.EMPTY_NOTICE === '1') warnOwner(sock, `👁️ A message from ${tagOf(sender)} arrived without its content (probably a view-once) and I asked your phone for it, but WhatsApp did not send it to this bot.\n${OPEN_ON_PHONE}`, 'viewonce', [sender]).catch(() => {});
  }, timing.answerWait);
  if (timer.unref) timer.unref();
  voAsked.set(id, timer);
  stats.viewOnceChased = (stats.viewOnceChased || 0) + 1;
  askPhoneAgain(sock, msg).then((ok) => {
    if (ok) console.log(`👁️ Request sent to the phone for message ${id.slice(0, 8)}. Waiting for its answer.`);
    if (!ok && voAsked.get(id) === timer) {
      clearTimeout(timer);
      voAsked.delete(id); // a later delivery may try again
    }
  }).catch(() => {});
}

// Called for EVERY incoming message, before the "seen before" check (see above). Never throws, never waits.
function early(sock, msg) {
  try {
    if (!msg || msg.key?.fromMe) return;
    const jid = msg.key?.remoteJid;
    if (!jid || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;
    if (!msg.message) {
      // announced but empty (this is how a hidden view-once looks): ask the phone for it
      if (hiddenStub(msg.messageStubType)) chaseHidden(sock, msg, jid);
      return;
    }
    const id = msg.key.id;
    // Only a message that really carries the view-once flag is opened. (The phone's answer to our request used to be opened
    // even without the flag, so an ordinary picture that had arrived late was reported as a view-once.)
    // `guess` is OFF unless the owner switched it on (`autoviewonce guess on`). It used to be ON, so an ordinary picture that had arrived
    // empty (common after a reconnect or in a busy group) was copied as a "Hidden picture", and looked like a view-once that never was.
    const assume = store.watchCfg('viewonce').guess === true && !!(id && voAsked.has(id)); // the phone's answer to our request: opened, but only called a view-once when it carries the flag
    const vo = findViewOnce(msg.message, assume);
    if (!vo) {
      const env = peel(msg.message);
      if (env.viewOnce) {
        // inside a view-once envelope, but nothing this bot knows how to open (WhatsApp keeps adding kinds): the console says what it holds
        const held = Object.keys(env.content).filter((k) => k !== 'messageContextInfo' && k !== 'senderKeyDistributionMessage');
        console.log(`👁️ A view-once message of a kind I cannot open yet arrived (it holds: ${held.join(', ') || 'nothing'}).`);
        const where = jid.endsWith('@g.us') ? 'a group' : 'a private chat';
        warnOwner(sock, `👁️ A view-once message of a kind I cannot open yet arrived in ${where}.\n▸ Open it on your phone. If this keeps happening, tell the developer: the console shows what it holds.`, 'viewonce-unknown').catch(() => {});
        return;
      }
      if (id && voAsked.has(id) && peel(msg.message).content && Object.keys(peel(msg.message).content).some((k) => /^(image|video|audio)Message$/.test(k))) {
        clearTimeout(voAsked.get(id));
        voAsked.delete(id);
        console.log(`👁️ The phone sent message ${id.slice(0, 8)}. It is an ordinary picture, video or voice note (no view-once flag), so it is ignored.`);
        return;
      }
      // a message that holds nothing at all (only envelope details) can be a view-once whose content was held back: ask the phone for it
      const content = peel(msg.message).content;
      const bare = Object.keys(content).every((k) => k === 'messageContextInfo' || k === 'senderKeyDistributionMessage');
      if (bare && !msg.messageStubType) chaseHidden(sock, msg, jid);
      return;
    }
    if (!vo.empty) {
      keepViewOnce(msg);
      if (!vo.guessed) vault.keep(sock, msg, vo, fetchMedia); // saved at once: after the phone opens it, WhatsApp no longer gives the file to anybody
    }
    viewOnce(sock, msg, jid.endsWith('@g.us'), assume).catch((e) => {
      problem('View-once', e);
      return warnOwner(sock, `👁️ I could not handle a view-once message.\nReason: ${String(e.message).slice(0, 100)}`, 'viewonce');
    });
  } catch (err) {
    // a watcher must never break message handling
  }
}

// ---------------------------------------------------------------- remember messages for anti-delete / anti-edit
async function remember(sock, msg, isGroup) {
  const wantDel = inScope(store.watchCfg('delete').mode, isGroup);
  const wantEdit = inScope(store.watchCfg('edit').mode, isGroup);
  if (!wantDel && !wantEdit) return;

  const message = msg.message;
  const kind = kindName(message);
  const item = {
    jid: msg.key.remoteJid, sender: isGroup ? msg.key.participant : msg.key.remoteJid,
    text: textOf(message), kind, message, ts: Number(msg.messageTimestamp) || 0,
  };
  cache.remember(msg.key.id, item); // text and the original message are kept at once, media follows

  if (wantDel && kind && kind !== 'document') {
    const { content: inner } = peel(message);
    const node = inner.imageMessage || inner.videoMessage || inner.audioMessage || inner.stickerMessage;
    const size = Number(node?.fileLength?.low ?? node?.fileLength) || 0;
    if (size && size > MAX_MEDIA) return;
    if (downloading >= 2) return;
    downloading += 1;
    try {
      const buffer = await media.download(sock, msg);
      if (buffer.length <= MAX_MEDIA) cache.remember(msg.key.id, { ...item, buffer, mime: node?.mimetype });
    } catch (err) {
      // the text is still kept
    } finally {
      downloading -= 1;
    }
  }
}

// ---------------------------------------------------------------- deleted / edited (shared by both ways WhatsApp tells us)
async function deletedCore(sock, { jid, id, deleter }) {
  const isGroup = jid.endsWith('@g.us');
  const cfg = store.watchCfg('delete');
  if (!inScope(cfg.mode, isGroup) || !id) return;
  const it = cache.get(id);
  if (!it) return; // we never saw the original
  if (!once(`del|${id}`)) return;
  console.log(`🗑️ Deleted message noticed in ${jid}`);

  const by = deleter && num(deleter) !== num(it.sender) ? `🧹 Deleted by ${tagOf(deleter)}` : '🧹 Deleted by the sender';
  const header = `🗑️ *Deleted message*\n👤 Sent by ${tagOf(it.sender)}\n${by}\n💬 In ${await chatName(sock, jid)}\n🕒 Sent ${it.ts ? clock.stamp(it.ts * 1000) : 'earlier'}`;
  try {
    await sendCopy(sock, dest(sock, cfg, jid), { ...it, mentions: deleter ? [deleter] : [] }, header, quotedOriginal(it, id));
    stats.deleted += 1;
  } catch (err) {
    problem('Anti-delete copy', err);
    await warnOwner(sock, `🗑️ I noticed a deleted message but could not send you the copy.\nReason: ${String(err.message).slice(0, 100)}`, 'delete');
  }
  cache.drop(id);
}

async function editedCore(sock, { jid, id, after, editor }) {
  const isGroup = jid.endsWith('@g.us');
  const cfg = store.watchCfg('edit');
  if (!inScope(cfg.mode, isGroup) || !after || !id) return;
  const it = cache.get(id);
  const before = it?.text || '(I did not see the original text)';
  if (before === after || !once(`edit|${id}|${after}`)) return;
  console.log(`✏️ Edited message noticed in ${jid}`);

  const sender = it?.sender || editor || jid;
  const header = `✏️ *Edited message*\n👤 By ${tagOf(sender)}\n💬 In ${await chatName(sock, jid)}\n🕒 ${clock.stamp(Date.now())}`;
  const body = { text: `${header}\n\n*Before:*\n${before}\n\n*After:*\n${after}`, mentions: [sender] };
  try {
    try {
      await sock.sendMessage(dest(sock, cfg, jid), body, it ? { quoted: quotedOriginal(it, id) } : undefined);
    } catch (err) {
      await sock.sendMessage(dest(sock, cfg, jid), body); // the reply-to-original part failed: send it plain
    }
    stats.edited += 1;
  } catch (err) {
    problem('Anti-edit copy', err);
    await warnOwner(sock, `✏️ I noticed an edited message but could not send you the copy.\nReason: ${String(err.message).slice(0, 100)}`, 'edit');
  }
  if (it) cache.remember(id, { ...it, text: after });
}

// An edit that arrives sealed in a secret envelope (newer WhatsApp): open it with the secret of the original message
async function secretEditCore(sock, msg, sec, who) {
  const jid = msg.key.remoteJid;
  const targetId = sec.targetMessageKey?.id;
  const type = sec.secretEncType;
  if (!targetId || type === 1 || type === 'EVENT_EDIT') return; // not a message edit
  stats.editSecret += 1;
  const it = cache.get(targetId);
  const secret = it && secretedit.findSecret(it.message);
  console.log(`🔒 Edit arrived in a secret envelope (original saved: ${it ? 'yes' : 'no'}, key: ${secret ? 'yes' : 'no'})`);
  if (!inScope(store.watchCfg('edit').mode, jid.endsWith('@g.us'))) return;
  if (!secret) {
    stats.editUnreadable += 1;
    return warnOwner(
      sock,
      `✏️ ${tagOf(who)} edited a message in ${await chatName(sock, jid)}, but I had not saved the original (it was sent before anti-edit was on, or before the bot last restarted), so I cannot read the new text.`,
      'editunknown',
      [who]
    );
  }
  const after = secretedit.decryptEdit({ sec, key: msg.key, secret });
  if (!after) {
    stats.editUnreadable += 1;
    console.log('🔒 Could not open the edit envelope.');
    return warnOwner(sock, `✏️ ${tagOf(who)} edited a message but I could not open the new text.`, 'editunknown');
  }
  return editedCore(sock, { jid, id: targetId, after, editor: who });
}

// ---------------------------------------------------------------- entry points
// A message arrived WITHOUT content. If auto view-once is on, say so (once a minute) instead of staying silent.
async function noContent(sock, msg) {
  const jid = msg.key?.remoteJid;
  if (!jid || msg.key.fromMe || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;
  const isGroup = jid.endsWith('@g.us');
  if (!inScope(store.watchCfg('viewonce').mode, isGroup)) return;
  stats.empty = (stats.empty || 0) + 1;
  console.log(`👁️ A message from ${num(isGroup ? msg.key.participant : jid)} arrived without content (stub ${msg.messageStubType ?? 'none'}). Possibly a view-once.`);
  // Many things arrive with no content (group events, messages that could not be decrypted, reactions...), and real view-once
  // files are already reported by their own notice. So this guess is only told to the owner when EMPTY_NOTICE=1 is set.
  if (process.env.EMPTY_NOTICE !== '1' || msg.messageStubType) return;
  await warnOwner(
    sock,
    `👁️ A message from ${tagOf(isGroup ? msg.key.participant : jid)} arrived in ${await chatName(sock, jid)} but WhatsApp sent me no content. If it was a view-once, this is why.\n${OPEN_ON_PHONE}`,
    'empty'
  );
}

// called for every incoming message
async function run(sock, msg) {
  const message = msg.message;
  if (!message) return;
  const jid = msg.key.remoteJid;
  if (!jid || jid.endsWith('@broadcast') || jid.endsWith('@newsletter')) return;
  const isGroup = jid.endsWith('@g.us');

  // edits and deletions can come wrapped in other envelopes: open them all first
  const { content } = peel(message);
  const pm = content.protocolMessage;
  if (content.secretEncryptedMessage && !msg.key.fromMe) {
    return secretEditCore(sock, msg, content.secretEncryptedMessage, isGroup ? msg.key.participant : jid);
  }
  if (pm) {
    if (msg.key.fromMe) return;
    const who = isGroup ? msg.key.participant : jid;
    console.log(`🔔 Protocol message in ${jid}: type ${pm.type}`);
    if (typeIs(pm.type, 0, 'REVOKE')) return deletedCore(sock, { jid, id: pm.key?.id, deleter: who });
    if (typeIs(pm.type, 14, 'MESSAGE_EDIT')) {
      stats.editEvents += 1;
      return editedCore(sock, { jid, id: pm.key?.id, after: textOf(pm.editedMessage || {}), editor: who });
    }
    return;
  }
  if (msg.key.fromMe) return;

  await remember(sock, msg, isGroup).catch(() => {}); // (view-once files are handled by early(), before the "seen before" check)
}

// called for "message updates": the other way WhatsApp reports edits and deletions
async function onUpdate(sock, updates) {
  for (const u of updates || []) {
    const key = u.key;
    if (!key || key.fromMe || !key.remoteJid || key.remoteJid.endsWith('@broadcast')) continue;
    const isGroup = key.remoteJid.endsWith('@g.us');
    const who = isGroup ? key.participant : key.remoteJid;
    const upd = u.update || {};

    const edited = upd.message?.editedMessage || upd.message?.protocolMessage;
    if (edited) {
      const info = editInfo(edited.message || edited);
      stats.editEvents += 1;
      console.log(`🔔 Edit update in ${key.remoteJid} (new text ${info.text ? 'found' : 'NOT found'})`);
      await editedCore(sock, { jid: key.remoteJid, id: info.id || key.id, after: info.text, editor: who });
      continue;
    }
    if (upd.messageStubType === 1 || upd.messageStubType === 'REVOKE') {
      await deletedCore(sock, { jid: key.remoteJid, id: key.id, deleter: upd.key?.participant || who });
    }
  }
}

const resetWarnings = () => lastWarn.clear(); // for tests

module.exports = { dest, timing, resetWarnings, run, early, noContent, onUpdate, findViewOnce, recentViewOnce, inScope, stats, fetchMedia, OPEN_ON_PHONE };
