const pkg = require('../package.json');
const brand = require('../core/brand');
const clock = require('../core/clock');
const { smallcaps: sc } = require('../core/fonts');
const store = require('../whatsapp/store');
const capacity = require('../core/capacity');
const { groupByCategory, mark, PLUGIN_MARK } = require('../whatsapp/categories');
const ownername = require('../whatsapp/ownername');

const chunk = (a, n) => Array.from({ length: Math.ceil(a.length / n) }, (_, i) => a.slice(i * n, i * n + n));
const RULE = '────────────────'; // short on purpose: long lines wrap on phones
// a block of aligned lines in WhatsApp monospace
const mono = (rows) => {
  const w = Math.max(...rows.map(([k]) => k.length)) + 2;
  return '```\n' + rows.map(([k, v]) => `${k.padEnd(w)}${v}`).join('\n') + '\n```';
};

// one category: the heading is always "┏ ❏ NAME ❏" (the owner's chosen style); the commands below keep their own symbol
function block(section, lines) {
  const sym = section.meta.symbol;
  return `┏ ❏ ${section.meta.title} ❏\n${lines.map((l) => `┃ ${sym} ${l}`).join('\n')}\n┗${sym}`;
}

const size = (mb) => (mb >= 1024 ? `${(mb / 1024).toFixed(mb >= 10240 ? 0 : 1)} GB` : `${mb} MB`);
// where the bot runs: a hosting panel, Termux on a phone, or a plain server
function host() {
  const e = process.env;
  if (e.P_SERVER_UUID || e.PTERODACTYL || e.SERVER_PORT) return 'Panel';
  if (String(e.PREFIX || '').includes('com.termux')) return 'Termux';
  return { linux: 'Linux server', darwin: 'Mac', win32: 'Windows' }[process.platform] || process.platform;
}

module.exports = {
  name: 'menu',
  category: 'general',
  description: 'Show the command menu (try: menu group, or menu kick for help with one command)',
  async run({ reply, commandList, prefix, args, isOwner, isAdmin, timing, sock, jid, msg }) {
    const sections = groupByCategory(commandList, isOwner);
    const all = sections.flatMap((s) => s.cmds);
    const query = (args[0] || '').toLowerCase().replace(/^[^a-z0-9]+/, '');

    // menu plugins: every plugin command in one place (they still live in their own categories)
    if (query === 'plugins') {
      const mine = all.filter((c) => c.pluginId);
      if (!mine.length) return reply(`🧩 *No plugin commands are active.*\n▸ _Plugins are managed with_ \`${prefix}plugin\``);
      const items = mine.map((c) => `*${c.name}*${mark(c)} _(${sections.find((s) => s.cmds.includes(c)).meta.title.toLowerCase()})_\n┃    _${c.description}_`);
      return reply(block({ meta: { title: 'PLUGIN COMMANDS', symbol: '✦' } }, items));
    }

    // menu <category>: every command of it with its description
    const section = sections.find((s) => s.key === query);
    if (query && section) {
      const items = section.cmds.map((c) => `*${c.name}*${mark(c)}\n┃    _${c.description}_`);
      return reply(block(section, items));
    }

    // menu <command>: help for one command
    if (query) {
      const c = all.find((x) => x.name === query || (x.aliases || []).includes(query));
      if (!c) return reply(`No command found for *${query}*.\n> Send ${prefix}menu to see everything.`);
      const who = c.realOwnerOnly ? 'Main owner' : c.ownerOnly ? 'Owner' : c.adminOnly ? 'Group admins' : 'Everyone';
      const rows = [
        ['Use', `${prefix}${c.name}`],
        ['Who', who],
        ['Where', c.groupOnly ? 'Groups only' : 'Groups and private'],
      ];
      if ((c.aliases || []).length) rows.push(['Also', c.aliases.map((a) => prefix + a).join(', ')]);
      if (c.botAdminRequired) rows.push(['Needs', 'Bot as admin']);
      return reply(`*${c.name.toUpperCase()}*${mark(c)}\n_${c.description}_\n${RULE}\n${mono(rows)}`);
    }

    // full menu: the header box, then the categories
    const custom = store.getAuto('menu') || {};
    const title = String(custom.title || brand.botName).toUpperCase();
    const mem = capacity.memory();
    const pct = mem.limitMB ? Math.min(100, Math.round((mem.usedMB / mem.limitMB) * 100)) : 0;
    const ms = timing && timing.receivedAt ? Math.max(0, Date.now() - timing.receivedAt) : 0;
    // The header: a framed box with the bot name in the top bar (『 NAME 』) and one ◈ line per detail. The category boxes below it
    // use "┏ ❏ NAME ❏", so the two never look the same. The Owner line is left out until WhatsApp has told the owner's name.
    // Platform, Usage and RAM are for the owner only. There is no picture or sticker: the menu is one text message.
    const owner = ownername.get(sock);
    const rows = [
      ...(owner ? [['Owner', owner]] : []),
      ['User', isOwner ? 'Owner' : isAdmin ? 'Group admin' : 'Member'],
      ['Prefix', `[ ${prefix || 'none'} ]`],
      ['Mode', store.getMode() === 'private' ? 'Private' : 'Public'],
      ['Commands', String(all.length)],
      ['Version', `[ ${pkg.version} ]`],
      ['Speed', `${ms} ms`],
      ['Uptime', clock.uptime()],
    ];
    if (isOwner) {
      rows.push(['Platform', host()], ['Usage', `${size(mem.usedMB)} of ${size(mem.limitMB)}`], ['RAM', `[${'█'.repeat(Math.round(pct / 10))}${'░'.repeat(10 - Math.round(pct / 10))}] ${pct}%`]);
    }
    const head = [
      `┏━━─『 ${title} 』─━━`,
      ...(custom.subtitle ? [`┃ ◈ ${custom.subtitle}`] : []),
      ...rows.map(([k, v]) => `┃ ◈ ${k}: ${v}`),
      '┃',
      '┃',
      '┗━━━━━━━━━━━━─···',
    ].join('\n');
    const body = sections.map((s) => block(s, s.cmds.map((c) => sc(c.name) + mark(c)))).join('\n\n');
    const tips =
      `> ${prefix}menu <category>  details of a category\n` +
      `> ${prefix}menu <command>  help for one command\n` +
      `> ${prefix}list  every command with its description\n` +
      (all.some((c) => c.pluginId) ? `> ${PLUGIN_MARK}  a command that comes from a plugin\n` : '') + '\n' +
      `${chunk(sections.map((s) => s.key), 5).map((r) => `_${r.join(' · ')}_`).join('\n')}\n` +
      `_${brand.botName} • v${pkg.version}_`;

    const whole = `${head}\n\n${body}\n\n${tips}`; // header and commands: ONE text message
    return reply(whole);
  },
};
