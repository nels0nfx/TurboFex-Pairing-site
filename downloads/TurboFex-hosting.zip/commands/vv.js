// Reveals a view-once picture, video or voice note: reply to it with "vv".
const media = require('../whatsapp/media');
const watchers = require('../whatsapp/watchers');
const clock = require('../core/clock');
const { ownerChat } = require('../whatsapp/owner');
const { getQuoted, num } = require('../whatsapp/utils');
const { peel, findViewOnce } = require('../whatsapp/unwrap');

module.exports = {
  name: 'vv',
  aliases: ['viewonce', 'reveal'],
  category: 'watch',
  slow: true,
  ownerOnly: true,
  needs: [],
  silentOnSticker: true, // run by a sticker (setstickercmd vv): no answer, no reaction in the chat; the file goes to the view-once chat
  weight: 'medium',
  description: 'Open a view-once picture, video or voice note: reply to it with vv (vv me = send it to your own chat)',
  async run({ sock, jid, msg, args, reply, prefix, botIds, silent }) {
    const q = getQuoted(msg);
    if (!q) return reply(`Reply to a view-once message with *${prefix}vv*.\n*${prefix}vv me* sends the file to your own chat instead of this one.`);

    const vo = findViewOnce(q.message);
    const inner = peel(q.message).content;
    const node = vo?.node || inner.imageMessage || inner.videoMessage || inner.audioMessage;
    if (!node) return reply('⚠️ That message has no picture, video or voice note in it.');
    const kind = inner.videoMessage ? 'video' : inner.audioMessage ? 'audio' : 'image';

    // A reply only carries a short copy of the quoted message, and for a view-once the file details can be missing from it.
    // If the bot saw the complete message lately, that one is used.
    const full = vo?.empty ? watchers.recentViewOnce(q.id) : null;
    const source = full || {
      key: { remoteJid: jid, id: q.id, participant: q.participant, fromMe: botIds.includes(num(q.participant)) },
      message: q.message,
    };
    const fullNode = full ? findViewOnce(full.message)?.node : null;
    let buffer;
    try {
      buffer = await watchers.fetchMedia(sock, source);
    } catch (err) {
      console.error('vv failed:', err.message);
      return reply(`⚠️ I could not open that file.\nReason: ${String(err.message).slice(0, 100)}\n${watchers.OPEN_ON_PHONE}`);
    }

    if (fullNode) Object.assign(node, { caption: node.caption || fullNode.caption, mimetype: node.mimetype || fullNode.mimetype, ptt: node.ptt ?? fullNode.ptt });
    // by sticker: to the chat chosen with viewoncejid (own chat, a chat, or the chat where it was sent); typed: here, or "me"
    const to = silent ? watchers.dest(sock, require('../whatsapp/store').watchCfg('viewonce'), jid) : (args[0] || '').toLowerCase() === 'me' ? ownerChat(sock) : jid;
    const caption = `👁️ *View-once opened*\n🕒 ${clock.stamp(Date.now())}${node.caption ? `\n\n${node.caption}` : ''}`;
    const opts = to === jid && !silent ? { quoted: msg } : undefined;
    if (kind === 'image') await sock.sendMessage(to, { image: buffer, caption }, opts);
    else if (kind === 'video') await sock.sendMessage(to, { video: buffer, caption }, opts);
    else await sock.sendMessage(to, { audio: buffer, mimetype: node.mimetype || 'audio/ogg; codecs=opus', ptt: !!node.ptt }, opts);
    if (to !== jid && !silent) await reply('✅ Sent to your chat.');
  },
};
