// play: always sends AUDIO. A song name or a link from almost any site (YouTube, TikTok, SoundCloud, Instagram,
// Facebook... anything the downloader supports) or a direct link to an audio file.
const ytdlp = require('../core/ytdlp');
const { downloadAudio, titleOf, searchFlat, youtubeId, MAX_MB, MAX_SECONDS } = require('../core/ytdlp');
const ytsearch = require('../core/ytsearch');
const songmatch = require('../core/songmatch');
const piped = require('../core/piped');
const audius = require('../core/audius');
const { readLimited } = require('../core/download');

const MAX_BYTES = MAX_MB * 1024 * 1024;
const DIRECT_AUDIO = /\.(mp3|m4a|ogg|opus|wav|aac|flac)(\?|#|$)/i;

async function sendAudio(sock, jid, msg, a) {
  const lines = [`🎵 *${a.title || 'Audio'}*`, a.artist && `👤 ${a.artist}`, a.duration && `⏱️ ${a.duration}`, a.url && `🔗 ${a.url}`].filter(Boolean);
  await sock.sendMessage(jid, { text: lines.join('\n') }, { quoted: msg });
  return sock.sendMessage(jid, { audio: a.buffer, mimetype: a.mimetype });
}

module.exports = {
  name: 'play',
  category: 'download',
  slow: true,
  weight: 'medium',
  needs: [],
  aliases: ['song', 'audio'],
  description: 'play <artist and song, or a link>: sends the audio (no cookies needed; YouTube, TikTok, SoundCloud and more)',
  async run({ sock, jid, msg, rest, reply, prefix, isOwner }) {
    if (!rest) return reply(`Type a song name or a link.\n${prefix}play calm down\n${prefix}play https://youtu.be/...`);

    // a direct link to an audio file
    if (/^https?:\/\/\S+$/i.test(rest) && DIRECT_AUDIO.test(rest)) {
      try {
        const res = await fetch(rest, { redirect: 'follow', signal: AbortSignal.timeout(60000), headers: { 'User-Agent': 'TurboFex' } });
        if (res.ok) {
          const type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
          if (Number(res.headers.get('content-length')) <= MAX_BYTES) {
            const buffer = await readLimited(res, MAX_BYTES);
            return sock.sendMessage(jid, { audio: buffer, mimetype: type.startsWith('audio/') ? type : 'audio/mpeg' }, { quoted: msg });
          }
        }
      } catch (err) {
        // the downloader below tries as well
      }
    }

    reply('⏳ *Getting your audio, one moment...*').catch(() => {}); // not awaited: the download starts at once
    const setup = { onSetup: () => reply('⏳ *Getting ready, one moment...*') };
    const isLink = /^https?:\/\//i.test(rest);
    const log = (what, err) => console.error(`Play (${what}) failed:`, err.message);
    let problem;

    // ---- A link: get exactly that. If it fails, find the same song by its title (only a CLOSE match is accepted).
    let query = isLink ? '' : rest;
    let wantedId = isLink ? youtubeId(rest) : null;
    if (isLink) {
      try {
        return await sendAudio(sock, jid, msg, await downloadAudio(rest, setup));
      } catch (err) {
        problem = err;
        log('link', err);
        if (err.code === 'TOO_LONG' || err.code === 'TOO_BIG') return reply(`⚠️ ${err.message}`);
      }
      if (wantedId) {
        try {
          return await sendAudio(sock, jid, msg, await piped.getAudio(wantedId, { maxBytes: MAX_BYTES, maxSeconds: MAX_SECONDS }));
        } catch (err) {
          log('Piped', err);
        }
        query = await titleOf(rest);
      }
    }

    // ---- A song name: look at SEVERAL results and pick the one that really is the song (not a cover, remix or 1 hour mix)
    let picks = [];
    if (query && !isLink) {
      // The YouTube search page is one plain web request (about a second). The downloader's own search has to start the downloader
      // program first, which alone takes several seconds, and then the download starts it a second time. So the search page goes
      // first and the downloader's search is the backup (before, it was the other way round).
      let found = [];
      try {
        found = await ytsearch.search(query, 6);
      } catch (err) {
        log('search page', err);
      }
      if (!found.length) {
        try {
          found = await searchFlat(query, { source: 'youtube', limit: 6, onSetup: setup.onSetup });
        } catch (err) {
          log('search', err);
        }
      }
      picks = songmatch.rank(found, query);
      // Only a result that really is the asked song is downloaded (all the asked words up to 3 words, three quarters after that).
      // Before, half the words were enough, and when NOTHING matched the best of the bad results was sent anyway: that is how a song
      // that was not asked for arrived. Now the answer is "not found", with the closest results to choose from.
      const right = picks.filter(songmatch.isRight);
      // download the best two (the first one can be blocked or too long while the second is fine)
      for (const pick of right.slice(0, 2)) {
        try {
          return await sendAudio(sock, jid, msg, await downloadAudio(pick.url, setup));
        } catch (err) {
          problem = err;
          log(`YouTube ${pick.id}`, err);
          if (err.code === 'TOO_BIG') return reply(`⚠️ ${err.message}`);
        }
      }
      // YouTube blocks this server (no cookies): the same video through a Piped server
      for (const pick of right.slice(0, 2)) {
        try {
          return await sendAudio(sock, jid, msg, await piped.getAudio(pick.id, { maxBytes: MAX_BYTES, maxSeconds: MAX_SECONDS }));
        } catch (err) {
          log(`Piped ${pick.id}`, err);
        }
      }
    }

    // ---- Other sites. A wrong song is worse than no song, so only a close match is accepted here.
    if (query) {
      try {
        const [best] = songmatch.rank(await searchFlat(query, { source: 'soundcloud', limit: 6 }), query);
        if (songmatch.isClose(best)) return await sendAudio(sock, jid, msg, await downloadAudio(best.url, setup));
      } catch (err) {
        log('SoundCloud', err);
      }
      try {
        const found = songmatch.rank((await audius.search(query, 6)).map((t) => ({ ...t, channel: t.artist })), query);
        if (songmatch.isClose(found[0])) {
          const t = found[0];
          const buffer = await audius.download(t);
          return await sendAudio(sock, jid, msg, { buffer, mimetype: 'audio/mpeg', title: t.title, artist: t.artist, duration: t.duration, url: t.url });
        }
      } catch (err) {
        log('Audius', err);
      }
    }

    if (problem?.code === 'BOT_BLOCK' || (!picks.length && !isLink)) {
      return reply(isOwner ? `⚠️ *I could not get that song.*\n▸ YouTube blocks this server and no other source had it.\n▸ *Fix:* send a cookies.txt with \`${prefix}ytcookies\`.` : '⚠️ *I could not find that song right now.*\n▸ Try another name, add the artist, or try again later.');
    }
    if (problem && ['NO_SPACE', 'TOO_LONG', 'TOO_BIG', 'TIMEOUT'].includes(problem.code)) return reply(ytdlp.explain(problem, { isOwner, prefix, what: 'that song' }));
    // nothing matched well enough: say so, and show the closest results so the right one can be chosen by its link
    const closest = picks.slice(0, 3).filter((p) => p.url);
    const hint = closest.length
      ? `\n\n▸ *Closest I found:*\n${closest.map((p, i) => `${i + 1}. ${p.title}${p.channel ? ` - ${p.channel}` : ''}\n${p.url}`).join('\n')}\n▸ _If one of these is it, send its link: ${prefix}play <link>_`
      : '';
    return reply(`⚠️ *I could not find that exact song.*\n▸ Try the artist and the title, for example \`${prefix}play rema calm down\`.${hint}`);
  },
};
